const URL = 'https://teachablemachine.withgoogle.com/models/Hy4w5e7f1/';
const THRESHOLD = 0.7;

window.onload = () => {
  let recognizer;

  async function createModel() {
    const checkpointURL = URL + 'model.json';
    const metadataURL = URL + 'metadata.json';

    recognizer = speechCommands.create(
      'BROWSER_FFT',
      undefined,
      checkpointURL,
      metadataURL
    );

    await recognizer.ensureModelLoaded();

    return recognizer;
  }

  async function init() {
    recognizer = await createModel();
    const classLabels = recognizer.wordLabels(); // get class labels
    recognizer.listen(
      result => {
        const Moby = result.scores[1];
        if (Moby > THRESHOLD) {
          console.log("Hey");
        }
      },
      {
        includeSpectrogram: true,
        probabilityThreshold: 0.75,
        invokeCallbackOnNoiseAndUnknown: true,
        overlapFactor: 0.5
      }
    );
  }

  init(); // Call the init function to start the recognizer
};
